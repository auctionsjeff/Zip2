﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            var engine = new Jurassic.ScriptEngine();
            engine.ExecuteFile(AppContext.BaseDirectory + "\\lib.js");
            var result = engine.Evaluate("test('123', false)");

            var bp = "";
        }
    }
}
